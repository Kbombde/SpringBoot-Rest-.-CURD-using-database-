package com.boot.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.dao.BookRepo;
import com.boot.entity.BookInfo;



@Service
public class BookService 
{
	@Autowired
	BookRepo repo;
	
	public BookInfo addRecord(BookInfo book) {
        return repo.save(book);
    }

    public List<BookInfo> findByGenre(String genre) {
        return repo.findByBookGenre(genre);
    }

    public List<Optional<BookInfo>> findByBookName(String name) {
        return repo.findByBookNameContaining(name);
    }

    public List<BookInfo> findByAuthor(String author) {
        return repo.findByAuthorNameContaining(author);
    }

    public List<BookInfo> findByPublishedDate(LocalDate date) {
        return repo.findByPublishedDate(date);
    }

    public void deleteByPriceRange(Double min, Double max) {
        repo.deleteByBookPriceBetween(min, max);
    }

    public BookInfo updateByBookName(BookInfo newBook , String bookName)
    {
    	List<Optional<BookInfo>> listOfBook = repo.findByBookNameContaining(bookName);
    	for (Optional<BookInfo> elementOfList : listOfBook) {
    		return  elementOfList.map(
                    book -> {
                        book.setBookName(newBook.getBookName());
                        book.setBookPrice(newBook.getBookPrice());
                        book.setAuthorName(newBook.getAuthorName());
                        book.setPublishedDate(newBook.getPublishedDate());
                        book.setBookGenre(newBook.getBookGenre());
                        return repo.save(book);
                    }).orElseGet(() -> {
                        return repo.save(newBook);
                    });
		}
		return newBook;
    	
    	
    }
    
    public BookInfo showbyId(long id) {
		return repo.findById(id).get();
	}

	public List<BookInfo> displayAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
}














































