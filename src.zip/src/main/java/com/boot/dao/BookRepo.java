package com.boot.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.entity.BookInfo;

import jakarta.transaction.Transactional;

@Transactional
public interface BookRepo extends JpaRepository<BookInfo, Long>
{

	List<BookInfo> findByBookGenre(String genre);

	List<Optional<BookInfo>> findByBookNameContaining(String name);

	List<BookInfo> findByAuthorNameContaining(String author);

	List<BookInfo> findByPublishedDate(LocalDate date);

	void deleteByBookPriceBetween(Double min, Double max);

}
