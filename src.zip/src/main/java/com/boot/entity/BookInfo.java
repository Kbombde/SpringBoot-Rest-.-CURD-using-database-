package com.boot.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
@Entity
@Data
public class BookInfo 
{
	    @Id
	    private Long bookId;
	    @Column(length=25)
	    private String bookName;
	    private Double bookPrice;
	    @Column(length=25)
	    private String authorName;
	    private LocalDate publishedDate;
	    @Column(length=25)
	    private String bookGenre;

}
