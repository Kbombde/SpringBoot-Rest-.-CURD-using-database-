package com.boot.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.boot.entity.BookInfo;
import com.boot.service.BookService;

@RestController
public class BookController
{
	@Autowired
	BookService serv;
	
	@PostMapping("/add-record-book")
    public BookInfo addRecord(@RequestBody BookInfo book) {
        return serv.addRecord(book);
    }
	
	@GetMapping("/show-all")
//	@RequestMapping(method = RequestMethod.GET, path = "/show-all")
	public List<BookInfo> displayAll() {
		return serv.displayAll();
	}

    @GetMapping("/show-by-genre/{genre}")
    public List<BookInfo> showByGenre(@PathVariable String genre) {
       System.out.println(serv.findByGenre(genre));
    	return serv.findByGenre(genre);
    }

    @GetMapping("/show-by-book-name/{name}")
    public List<Optional<BookInfo>> showByBookName(@PathVariable String name) {
        return serv.findByBookName(name);
    }

    @GetMapping("/show-by-author/{author}")
    public List<BookInfo> showByAuthor(@PathVariable String author) {
        return serv.findByAuthor(author);
    }

    @PutMapping("/update-book-by-name/{name}")
    public BookInfo updateByBookName(@PathVariable String name, @RequestBody BookInfo book) {
        return serv.updateByBookName(book, name);
    }

    @DeleteMapping("/delete-by-price-range/{min}/{max}")
    public void deleteByPriceRange(@PathVariable Double min, @PathVariable Double max) {
        serv.deleteByPriceRange(min, max);
    }

    @GetMapping("/show-by-published-date/{date}")
    public List<BookInfo> showByPublishedDate(@PathVariable LocalDate date) {
        return serv.findByPublishedDate(date);
    }
}
